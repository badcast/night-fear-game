 
#include <SDL2/SDL.h>

namespace ImageExternsion{

#define function void

function create_primitive(){
/*

    int sz = display.w * display.h * 4;
    void * pixels = SDL_malloc(sz);
    int pitch = display.w * 4;
    SDL_RenderReadPixels(render->renderer, nullptr, SDL_PIXELFORMAT_RGBA8888, pixels, pitch);


    SDL_Surface *su = SDL_CreateRGBSurfaceFrom(pixels, display.w, display.h, 32, pitch, 0xff000000, 0x00ff0000, 0x0000ff00, 0x000000ff);
    IMG_SavePNG(su, "/home/badcast/Desktop/xxx.png");

*/
}

}
