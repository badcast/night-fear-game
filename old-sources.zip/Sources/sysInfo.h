#pragma once

#include "framework.h"

const std::size_t get_process_privateMemory();

const std::size_t get_process_sizeMemory();
