﻿// pch.h: это предварительно скомпилированный заголовочный файл.

#ifndef PCH_H
#define PCH_H

// Добавьте сюда заголовочные файлы для предварительной компиляции

#include "framework.h"
#include "framework_ex.h"

#endif //PCH_H
